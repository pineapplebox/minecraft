WorldEdit
Copyright (c) 2010 sk89q <http://www.sk89q.com>
Licensed under the GNU Lesser General Public License v3

Introduction
------------

WorldEdit is a powerful in-game world manipulation plugin with
support for working with block data, copying and pasting regions,
undoing and redoing operations, loading and saving .schematic
files, and much more.

For usage help, see:
http://github.com/sk89q/worldedit/wiki/Usage

Thanks to grum for writing the terrain smoother.